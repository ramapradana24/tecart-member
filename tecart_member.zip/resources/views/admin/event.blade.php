@extends('layouts.app')

@section('page-title')
Event
@endsection

@section('content')

@endsection