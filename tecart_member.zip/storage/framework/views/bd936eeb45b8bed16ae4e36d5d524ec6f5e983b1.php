<?php
    $name = \Request::route()->getName();
?>
<div class="be-left-sidebar">
    <div class="left-sidebar-wrapper"><a href="#" class="left-sidebar-toggle"><?php echo $__env->yieldContent('page-title'); ?></a>
        <div class="left-sidebar-spacer">
        <div class="left-sidebar-scroll">
            <div class="left-sidebar-content">
            <ul class="sidebar-elements">
                <li class="divider">Menu</li>
                <li class="<?php echo e(($name == 'profile.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('profile.index')); ?>"><i class="icon mdi mdi-account-o"></i><span>Profile</span></a></li>
                <li><a href="index.html"><i class="icon mdi mdi-search"></i><span>Find Event</span></a></li>
                <li><a href="index.html"><i class="icon mdi mdi-assignment-o"></i><span>My Event</span></a></li>

                <?php if(Auth::user()->is_admin == 1): ?>
                <li class="parent"><a href="#"><i class="icon mdi mdi-settings"></i><span>Administrator</span></a>
                    <ul class="sub-menu">
                      <li class="<?php echo e(($name == 'event.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('event.index')); ?>">Event</a>
                      </li>
                      <li><a href="charts-sparkline.html">Member</a>
                      </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
            </div>
        </div>
        </div>
    </div>
</div>