<?php $__env->startSection('page-title'); ?>
Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/lib/select2/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="app">
  <Profile></Profile>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/lib/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/lib/moment.js/min/moment.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/profile.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>